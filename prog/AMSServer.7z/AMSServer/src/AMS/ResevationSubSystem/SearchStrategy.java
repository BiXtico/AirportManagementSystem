
package AMS.ResevationSubSystem;

public interface SearchStrategy {
    
     public void searchMethod();
}
