
package AMS.ResevationSubSystem;


public class SearchByDestination implements SearchStrategy {
    
     @Override
    public void searchMethod() {
        // search flights in database
        // search through using destination of flights
    }
}
