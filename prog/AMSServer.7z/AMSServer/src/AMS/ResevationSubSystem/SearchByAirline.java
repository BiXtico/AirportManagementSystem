
package AMS.ResevationSubSystem;


public class SearchByAirline implements SearchStrategy {

    @Override
    public void searchMethod() {
        // search flights
        // do database search for throgh flights using airline
    }
    
}
