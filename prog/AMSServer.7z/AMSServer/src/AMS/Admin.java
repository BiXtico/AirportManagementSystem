
package AMS;


public class Admin {
    
}
