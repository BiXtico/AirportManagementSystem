
package AMS.ResevationSubSystem;


public interface FeedbackROI {
    
}
