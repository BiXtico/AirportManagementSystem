
package AMS.DataModels;


import java.rmi.RemoteException;


public class SystemManager  {

    public SystemManager() throws RemoteException {
        
    }

    public int add(int x, int y) throws RemoteException {
        return x + y;
    }

    public int sub(int x, int y) throws RemoteException {
        return x - y;
    }

}
