
package AMS.DataModels;


public class Admin {
    
}
