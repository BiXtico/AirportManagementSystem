/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AMS.Controllers;

import AMS.Interfaces.AdminInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author mahmo
 */
public class AdminController {
    
    private static AdminInterface currentA;
     
    public void LookupAdmin(String username, int password) throws RemoteException {
        try {
            int i = 0;
            Registry registry = LocateRegistry.getRegistry(1099);
            while (registry.lookup("pass" + i) != null) {
                AdminInterface AI = (AdminInterface) registry.lookup("pass" + i);
                if (AI.getLoginInUsername().equals(username) && AI.getLoginInSSN() == password) {
                    currentA = AI;
                    break;
                }
                System.out.println("The new result is " + AI);
                ++i;
            }
        } catch (NotBoundException | RemoteException ex) {
            System.out.println("Exception occured, Error Client side try connection failed, can't read registery binds");
        }
    }
    public AdminInterface getCurrentP() {
        return currentA;
    } 
}
